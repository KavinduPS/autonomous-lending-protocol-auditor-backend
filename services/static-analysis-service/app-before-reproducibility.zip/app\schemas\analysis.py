from typing import Literal
from pydantic import BaseModel, Field
from app.schemas.finding import Finding


class AnalysisRequest(BaseModel):
    audit_id: str = Field(min_length=1, max_length=100)
    source_code: str = Field(min_length=1, max_length=200_000)

class AnalysisResponse(BaseModel):
    audit_id: str
    status: Literal["completed"] = "completed"
    finding_count: int
    findings: list[Finding]