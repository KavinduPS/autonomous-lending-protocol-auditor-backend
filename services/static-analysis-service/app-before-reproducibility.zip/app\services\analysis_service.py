import tempfile
from pathlib import Path

from app.parsers.slither_parser import parse_slither_result
from app.schemas.analysis import AnalysisRequest, AnalysisResponse
from app.tools.slither_runner import PROJECT_ROOT, run_slither
from app.services.compiler_service import validate_compilation


def analyze_contract(request: AnalysisRequest) -> AnalysisResponse:
    if not request.source_code.strip():
        raise ValueError("Solidity source code cannot be blank.")
    validate_compilation(request.source_code)
    workspace_root = PROJECT_ROOT / "workspaces"
    workspace_root.mkdir(parents=True, exist_ok=True)
   
    # Every request gets its own directory and fixed source filename.
    with tempfile.TemporaryDirectory(
        prefix="audit-",
        dir=workspace_root,
    ) as directory:
        source_path = Path(directory) / "Contract.sol"
        source_path.write_text(request.source_code, encoding="utf-8")

        # No detector filter: run Slither's default detector suite.
        raw_result = run_slither(str(source_path))
        findings = parse_slither_result(raw_result)

        return AnalysisResponse(
            audit_id=request.audit_id,
            finding_count=len(findings),
            findings=findings,
        )