from app.schemas.finding import Finding, FindingLocation


def parse_slither_result(result: dict) -> list[Finding]:
    if result.get("success") is not True:
        raise ValueError("Cannot parse an unsuccessful Slither result.")

    findings = []

    # Slither can return "results": {} when nothing is found.
    detectors = result.get("results", {}).get("detectors", [])

    for detector in detectors:
        locations = []
        seen_locations = set()

        for element in detector.get("elements", []):
            mapping = element.get("source_mapping", {})

            # Prefer project-relative paths in service responses.
            filename = (
                mapping.get("filename_relative")
                or mapping.get("filename_short")
            )

            if not filename:
                continue

            filename = filename.replace("\\", "/")
            lines = mapping.get("lines", [])

            start_line = min(lines) if lines else None
            end_line = max(lines) if lines else None

            location_key = (filename, start_line, end_line)

            if location_key in seen_locations:
                continue

            seen_locations.add(location_key)

            locations.append(
                FindingLocation(
                    file=filename,
                    start_line=start_line,
                    end_line=end_line,
                )
            )

        findings.append(
            Finding(
                finding_id=detector["id"],
                rule_id=detector["check"],
                description=detector["description"].strip(),
                severity=detector["impact"],
                confidence=detector["confidence"],
                reference=detector.get("reference"),
                locations=locations,
            )
        )

    return findings