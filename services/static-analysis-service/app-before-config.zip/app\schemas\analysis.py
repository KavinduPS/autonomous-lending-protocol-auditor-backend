from typing import Literal
from pydantic import BaseModel, Field
from app.schemas.finding import Finding


class AnalysisRequest(BaseModel):
    audit_id: str = Field(min_length=1, max_length=100)
    source_code: str = Field(min_length=1, max_length=200_000)

class AnalysisMetadata(BaseModel):
    source_sha256: str
    slither_version: str
    compiler_version: str


class AnalysisResponse(BaseModel):
    audit_id: str
    status: Literal["completed"] = "completed"
    finding_count: int
    metadata: AnalysisMetadata
    findings: list[Finding]
