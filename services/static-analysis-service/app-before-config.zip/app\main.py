from fastapi import FastAPI
from app.api.routers.analysis import router as analysis_router
app = FastAPI()

app = FastAPI(title="Static Analysis Service")

app.include_router(analysis_router)

@app.get("/health")
def health():
    return {"service": "static-analysis-service", "status": "ok"}
